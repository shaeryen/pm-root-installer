# PM-APP — Deploy con Docker

Questa applicazione è distribuita tramite Docker e può essere configurata tramite un file esterno (`config.env`).  
L’utente finale può modificare **solo** il file `config.env` senza toccare il `docker-compose.yml` o l’immagine Docker.

---

## 📁 Struttura del pacchetto

```
pm-app/
│
├── docker-compose.yml
├── config.env
└── README.md
```

---

## 🔧 1. Configurazione tramite `config.env`

Il file `config.env` contiene **tutte le variabili configurabili** dell’applicazione.  
Ogni variabile è **opzionale**: se non viene definita, Spring Boot userà automaticamente il valore di default presente
in `application.properties`.

### Esempio di configurazione (Windows + WSL)

```
DB_VOLUME=/mnt/c/Users/NOME/PM_DB
DOCS_VOLUME=/mnt/c/Users/NOME/PM_Documents
LOGS_VOLUME=/mnt/c/Users/NOME/PM_Logs
```

### Esempio di configurazione (Linux)

```
DB_VOLUME=/opt/pm/db
DOCS_VOLUME=/opt/pm/documents
LOGS_VOLUME=/opt/pm/logs
```

> 💡 **Nota:** Se non modifichi una variabile, verrà usato il valore di default definito nell’applicazione.

---

## ▶️ 2. Avvio dell’applicazione

Assicurati di avere Docker e Docker Compose installati.

Avvia l’app:

```
docker compose up -d
```

Docker:

- legge automaticamente `config.env`
- sostituisce le variabili nel compose
- monta i volumi corretti
- avvia il container

---

## ⏹️ 3. Arresto dell’applicazione

```
docker compose down
```

---

## 🔄 4. Aggiornamento dell’immagine

```
docker pull myapp:latest
docker compose up -d
```

---

## 📌 Note importanti

- **Non modificare il file `docker-compose.yml`**  
  Tutta la configurazione deve essere fatta in `config.env`.

- **Non modificare l’immagine Docker**  
  Tutte le proprietà sono overrideabili tramite variabili d’ambiente.

- **Le variabili mancanti in `config.env` usano automaticamente i default**  
  definiti nel `application.properties`.